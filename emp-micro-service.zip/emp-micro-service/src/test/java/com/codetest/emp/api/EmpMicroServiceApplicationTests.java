package com.codetest.emp.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
