package com.codetest.emp.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codetest.emp.api.entity.Employee;
import com.codetest.emp.api.service.EmployeeService;

@RestController
@RequestMapping(produces = "application/hal+json", value = "/api")

public class EmployeeController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeController.class);
	
	public static final String EMP_URL = "/employees";

	public static final String GET_EMP_BY_ID = EMP_URL+"/{empId}";



	@Autowired
	private EmployeeService empService;

	@PostMapping(EMP_URL)
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee emp) {

		LOGGER.info("Preparing to add employee");
		if (emp != null) {
			Employee result = empService.addEmployee(emp);

			return new ResponseEntity<>(result, HttpStatus.CREATED);

		} else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(EMP_URL)
	public ResponseEntity<List<Employee>> getAllEmployees() {

		LOGGER.info("Preparing to get all  employees");
		List<Employee> empList = empService.getAllEmployees();

		if (empList != null && empList.size() > 0) {
			return new ResponseEntity<>(empList, HttpStatus.OK);

		}
		else {
			
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);

		}

	}
	
	@GetMapping(GET_EMP_BY_ID)
	public ResponseEntity<Employee> getEmployeeById(@PathVariable long empId) {

		LOGGER.info("Preparing to get employees");
		Employee empInfo = empService.getEmployeeById(empId);

		if (empInfo != null) {
			return new ResponseEntity<>(empInfo, HttpStatus.OK);

		}
		else {
			
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);

		}

	}

}
