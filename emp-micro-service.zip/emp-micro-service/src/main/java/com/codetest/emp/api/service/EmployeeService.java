package com.codetest.emp.api.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codetest.emp.api.entity.Employee;
import com.codetest.emp.api.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository empRepository;

	public Employee addEmployee(Employee emp) {

		return empRepository.save(emp);

	}

	public Employee getEmployeeById(long empId) {

		Optional<Employee> employee = empRepository.findById(empId);
		
		if(employee.isPresent()) {
			return employee.get();
		}
		else {
			return null;
		}

	}

	public List<Employee> getAllEmployees() {

		return (List<Employee>) empRepository.findAll();

	}

}
